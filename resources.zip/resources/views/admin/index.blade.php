@extends('admin.layouts.main')
@push('title')
    <title>Admin | Dashboard</title>
@endpush
@section('main-section')
    		<!-- Page Wrapper -->
		<div class="page-wrapper">
			<!-- Page Content -->
			<div class="content container-fluid">
				<div class="crms-title row bg-white text-center">
					<h4>Welcome to your Admin Dashboard</h4>
				</div>
			</div>
			<!-- /Page Content -->
		</div>
		<!-- /Page Wrapper -->
@endsection