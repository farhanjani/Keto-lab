@include('layout.header')
    @yield('main-section')
@include('layout.footer')
